const client = ZAFClient.init();

async function initialiseApp() {
  const statusElement = document.getElementById("status");

  try {
    const ticketData = await client.get("ticket.requester.email");
    const email = ticketData["ticket.requester.email"];

    if (!email) {
      statusElement.textContent =
        "This ticket does not have a requester email.";
      return;
    }

    statusElement.textContent = `Requester email: ${email}`;

    await client.invoke("resize", {
      height: document.body.scrollHeight + 20,
    });
  } catch (error) {
    console.error(error);
    statusElement.textContent = "Unable to read the ticket requester.";
  }
}

initialiseApp();
